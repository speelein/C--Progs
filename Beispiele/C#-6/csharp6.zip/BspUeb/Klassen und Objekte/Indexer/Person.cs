class Person {
	public string Vorname;
	public string Name;
	public Person Next;
	public Person(string vorname, string nachname) {
		Vorname = vorname;
		Name = nachname;
	}
}
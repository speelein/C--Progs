using System;
class BruchRechnung {
	static void Main() {
		Bruch b = new Bruch(12, 18, "b = ");
		b.Kuerze();
		b.Zeige();
        Console.ReadLine();
    }
}

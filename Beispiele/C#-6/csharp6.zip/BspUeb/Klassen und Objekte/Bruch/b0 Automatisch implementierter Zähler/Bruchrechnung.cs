using System;
class Bruchrechnung {
    static void Main() {
        Bruch b = new Bruch();
        b.Zeige();
    }
}

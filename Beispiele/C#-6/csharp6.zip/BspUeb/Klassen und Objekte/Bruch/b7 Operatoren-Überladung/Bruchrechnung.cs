using System;
class BruchRechnung {
	static void Main() {
        Bruch b1 = new Bruch(1, 2, "b1 = ");
        b1.Zeige();
        Bruch b2 = new Bruch(1, 4, "b2 = ");
        b2.Zeige();
        Bruch b3 = b1 + b2;
        b3.Etikett = "Summe = ";
        b3.Zeige();
	}
}

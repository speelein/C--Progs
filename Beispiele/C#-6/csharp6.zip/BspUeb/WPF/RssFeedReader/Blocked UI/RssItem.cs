﻿namespace RssFeedReader {
	internal class RssItem {
		public string Title { get; internal set; }
		public string Description { get; internal set; }
		public string Url { get; internal set; }
	}
}
﻿// Datei Prog.cs
using System;
using MathExt;

class Prog {
	static void Main() {
		double pi = 3.14;
		Console.WriteLine(pi.H(2));
	}
}

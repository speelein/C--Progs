﻿using System;

class Prog {
    static void Main() {
        int i = 4711;
        Console.WriteLine("i hat den Wert: " + i);
    }
}

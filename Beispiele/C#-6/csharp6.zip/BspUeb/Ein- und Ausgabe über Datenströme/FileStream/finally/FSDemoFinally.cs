using System;
using System.IO;

class FSDemoUsing {
	static void Main() {
		String name = "demo.bin";
		byte[] arr = { 0, 1, 2, 3, 4, 5, 6, 7 };
		FileStream fs = null;
		try {
			fs = new FileStream(name, FileMode.CreateNew);
			fs.Write(arr, 0, arr.Length);
			fs.Position = 0;
			fs.Read(arr, 0, arr.Length);
			foreach (byte b in arr)
				Console.WriteLine(b);
		} finally {
			if (fs != null)
				fs.Close();
		}
		File.Delete(name);
	}
}
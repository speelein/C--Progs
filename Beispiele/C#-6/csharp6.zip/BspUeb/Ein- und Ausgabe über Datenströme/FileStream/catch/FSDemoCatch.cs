using System;
using System.IO;

class FSDemoCatch {
	static void Main() {
		String name = "demo.bin";
		byte[] arr = { 0, 1, 2, 3, 4, 5, 6, 7 };
		FileStream fs = null;
		try {
			fs = new FileStream(name, FileMode.CreateNew);
			fs.Write(arr, 0, arr.Length);
			fs.Position = 0;
			fs.Read(arr, 0, arr.Length);
			foreach (byte b in arr)
				Console.WriteLine(b);
		} catch (Exception e) {
			Console.WriteLine("Der Schreib-, Lesevorgang ist gescheitert:\n" + e.Message);
		} finally {
			if (fs != null)
				fs.Close();
		}
		try {
			File.Delete(name);
		} catch (Exception e) {
			Console.WriteLine("\nDie Datei kann nicht gel�scht werden:\n" + e.Message);
		}
	}
}

//using System;
//using System.IO;

//class FSDemoCatch {
//	static void Main() {
//		String name = "demo.bin";
//		byte[] arr = { 0, 1, 2, 3, 4, 5, 6, 7 };
//		try {
//			using (FileStream fs = new FileStream(name, FileMode.CreateNew)) {
//				fs.Write(arr, 0, arr.Length);
//				fs.Position = 0;
//				fs.Read(arr, 0, arr.Length);
//				foreach (byte b in arr)
//					Console.WriteLine(b);
//			}
//			File.Delete(name);
//		} catch (Exception e) {
//			Console.WriteLine("Die FileStream-Demo ist gescheitert:\n" + e.Message);
//		}
//	}
//}

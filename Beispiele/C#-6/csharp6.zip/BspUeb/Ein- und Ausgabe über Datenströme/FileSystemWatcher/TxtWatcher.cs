using System;
using System.IO;

public class TxtWatcher {
	static void Main(String[] args) {
		using (FileSystemWatcher watcher = new FileSystemWatcher(args[0])) {

			// Zu �berwachen: �ndern und Umbenennen von Dateien
			watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;
			// Filter f�r Dateinamen
			watcher.Filter = "*.txt";

			// Ereignisbehandlungmethoden registrieren
			watcher.Changed += watcher_Changed;
			watcher.Created += watcher_Changed;
			watcher.Deleted += watcher_Changed;
			watcher.Renamed += watcher_Renamed;

			// �berwachung aktivieren
			watcher.EnableRaisingEvents = true;

			Console.WriteLine("TxtWatcher gestartet. Beenden mit 'q'\n");
			Console.WriteLine("�berwachter Ordner: " + args[0] + "\n");
			ConsoleKeyInfo cki;
			do
				cki = Console.ReadKey(true);
			while (cki.KeyChar != 'q');
		}
	}

	// Ereignisroutinen implementieren
	static void watcher_Changed(Object source, FileSystemEventArgs e) {
		Console.WriteLine("Datei {0} {1}", e.Name, e.ChangeType);
	}

	static void watcher_Renamed(Object source, RenamedEventArgs e) {
		Console.WriteLine("Datei {0} umbenannt in {1}", e.OldName, e.Name);
	}
}

﻿using System;
class HalloMB
{
    static void Main()
    {
        System.Windows.MessageBox.Show("Hallo Allerseits!");
    }
}

using System;
class Bruchrechnung {
	static void Main() {
        Bruch b = new Bruch();
		b.Frage();
		b.Kuerze();
		b.Etikett = "b";
		b.Zeige();
	}
}

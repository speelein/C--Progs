using System;
class Bruchrechnung {
    static void Main() {
        var b1 = new Bruch(1, 2, "b1");
        b1.Zeige();
        var b2 = new Bruch(1, 4, "b2");
        b2.Zeige();
        var b3 = b1 + b2;
        b3.Zeige();
    }
}

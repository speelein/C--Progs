using System;
class Bruchrechnung {
    static void Main() {
        var b = new Bruch(7, 8, "");
        Console.WriteLine(b);
    }
}

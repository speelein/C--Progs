using System;

namespace ZIMK.CSC {

	class Bruchaddition {
		static void Main() {
			Bruch b = new Bruch();

			Console.WriteLine("K�rzen von Br�chen\n" +
							  "------------------\n");
			b.Frage();
			b.Kuerze();
			b.Etikett = "Der gek�rzte Bruch:";
			b.Zeige();
			Console.Read();
		}
	}
}
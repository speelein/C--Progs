﻿using System;
class Prog {
    static StreckenSammlung strKoll = new StreckenSammlung();
    static void Main() {
        ref Strecke strecke = ref strKoll.FindeStrecke(12);
        if (strecke.Li != -1)
            Console.WriteLine("Treffer in (" + strecke.Li + ", " + strecke.Re + ")");
        else
            Console.WriteLine("Kein Treffer");
    }
}

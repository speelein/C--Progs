﻿using System;

readonly public struct Strecke {
    public int Li { get; }
    public int Re { get; }
    public Strecke(int li, int re) {
        Li = li; Re = re;
    }
}

class StreckenSammlung {
    const int anz = 10, max = 100;
    Strecke[] strecken;
    Strecke nf = new Strecke(-1, -1);

    internal StreckenSammlung() {
        strecken = new Strecke[anz];
        Random zzg = new Random();
        for (int i = 0; i < anz; i++) {
            int start = zzg.Next(max - 4);
            strecken[i] = new Strecke(start, start + 5);
        }
    }

    internal ref Strecke FindeStrecke(int x) {
        for (int i = 0; i < anz; i++)
            if (x >= strecken[i].Li && x <= strecken[i].Re)
                return ref strecken[i];
        return ref nf;
    }
}

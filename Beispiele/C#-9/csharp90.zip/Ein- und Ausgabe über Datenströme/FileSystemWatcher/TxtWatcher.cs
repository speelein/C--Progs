﻿using System;
using System.IO;

class TxtWatcher {
	static void Main(string[] args) {
		using var watcher = new FileSystemWatcher(args[0]);

		// Zu Überwachen: Ändern und Umbenennen von Dateien
		watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;
		// Filter für Dateinamen
		watcher.Filter = "*.txt";

		// Ereignisbehandlungmethoden registrieren
		watcher.Changed += ChangedHandler;
		watcher.Created += ChangedHandler;
		watcher.Deleted += ChangedHandler;
		watcher.Renamed += RenamedHandler;

		// Überwachung aktivieren
		watcher.EnableRaisingEvents = true;

		Console.WriteLine("TxtWatcher gestartet. Beenden mit 'q'\n");
		Console.WriteLine("Überwachter Ordner: " + args[0] + "\n");
		ConsoleKeyInfo cki;
		do
			cki = Console.ReadKey(true);
		while (cki.KeyChar != 'q');
	}

	static void ChangedHandler(object source, FileSystemEventArgs e) {
		Console.WriteLine("Datei {0} {1}", e.Name, e.ChangeType);
	}

	static void RenamedHandler(object source, RenamedEventArgs e) {
		Console.WriteLine("Datei {0} umbenannt in {1}", e.OldName, e.Name);
	}
}

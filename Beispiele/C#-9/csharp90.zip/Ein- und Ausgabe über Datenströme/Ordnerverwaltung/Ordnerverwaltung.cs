﻿using System;
using System.IO;

class Ordnerverwaltung {
	static void Main() {
		const string dir1 = @"U:\Eigene Dateien\C#\EA\";
		const string dir2 = @"U:\Eigene Dateien\C#\EA\Sub\";

		// Verzeichnis erstellen (setzt das LW U: voraus)
		Directory.CreateDirectory(dir2);
		Directory.SetCurrentDirectory(dir1);

		using (var sw = File.CreateText(dir1 + "demo.txt"))
			sw.WriteLine("Directory-Demo");

		// Über Dateien informieren (mit Filter)
		var di = new DirectoryInfo(".");
		FileInfo[] fia = di.GetFiles("*.txt");
		Console.WriteLine("txt-Dateien in {0}", di.FullName);
		Console.WriteLine("  {0, -20} {1, -20}", "Name", "Letzte Änderung");
		foreach (FileInfo fi in fia)
			Console.WriteLine("  {0, -20} {1, -20}", fi.Name, fi.LastWriteTime);

		// Über Unterordner informieren
		DirectoryInfo[] dia = di.GetDirectories();
		Console.WriteLine("\n\nOrdner in {0}", di.FullName);
		Console.WriteLine("  {0, -20} {1, -20}", "Name", "Letzte Änderung");
		foreach (DirectoryInfo die in dia)
			Console.WriteLine("  {0, -20} {1, -20}", die.Name, die.LastWriteTime);

		Directory.SetCurrentDirectory(dir1 + "\\..");
		Console.WriteLine("\nDer Ordner " + dir1 + " wird nach Enter gelöscht.");
		Console.ReadLine();

		// Ordner löschen
		Directory.Delete(dir1, true);
	}
}

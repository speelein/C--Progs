﻿using System;
using System.IO;

class Mittelwerte {
    static void Main(string[] args) {
        try {
            char[] sep = new char[] { ';' };
            using (var fs = new FileStream(args[0], FileMode.Open, FileAccess.Read))
            using (var sr = new StreamReader(fs)) {
                string s = sr.ReadLine();
                string[] tokens = s.Split(sep);
                Console.WriteLine("Mittelwertsberechnung für die Datei " + args[0] + "\n");
                int nVar = tokens.Length;
                double temp;
                double[] means = new double[nVar];
                int[] nValid = new int[nVar];
                int n = 0;
                do {
                    n++;
                    tokens = s.Split(sep);
                    if (tokens.Length != nVar) {
                        Console.WriteLine("Warnung: Falsche Anzahl von Werten in Zeile " + n);
                        Console.WriteLine(" \"" + s + "\"");
                    } else
                        for (int i = 0; i < nVar; i++) {
                            if (Double.TryParse(tokens[i], out temp)) {
                                means[i] += temp;
                                nValid[i]++;
                            } else {
                                Console.WriteLine("Warnung: Token " + (i + 1) + " in Zeile " + n + " ist keine Zahl.");
                                Console.WriteLine(" \"" + s + "\"");
                            }
                        }
                } while ((s = sr.ReadLine()) != null);

                Console.WriteLine("\n            Variable           Mittelwert         Valide Werte");
                for (int i = 0; i < means.Length; i++)
                    if (nValid[i] > 0)
                        Console.WriteLine("{0, 20} {1, 20:f3} {2, 20}", i + 1, means[i] / nValid[i], nValid[i]);
            }
        } catch (Exception ex) {
            Console.WriteLine(ex);
            Environment.Exit(1);
        }
    }
}

using System;
using System.Collections.Generic;

[Serializable]
public class Rechnung {
	public DateTime Datum { get; set; }
	public double Betrag { get; set; }
}

[Serializable]
public class Kunde {
	public int Nr { get; private set; }
	public string Vorname { get; set; }
	public string Name { get; set; }
	readonly List<Rechnung> Rechnungen = new();
	[NonSerialized]
	bool kredit;

	public Kunde(int nr, string vorname, string name, bool kredit) {
		Nr = nr;
		Vorname = vorname;
		Name = name;
		this.kredit = kredit;
	}

	public void Kaufen(DateTime datum, double betrag) {
		Rechnungen.Add(new Rechnung { Datum = datum, Betrag = betrag });
	}

	public void Prot() {
		Console.WriteLine("\nKundennummer: \t" + Nr);
		Console.WriteLine("Name: \t\t" + Vorname + " " + Name);
		Console.WriteLine("Kredit: \t" + kredit);
		Console.WriteLine("Rechnungen:");
		foreach (var re in Rechnungen)
			Console.WriteLine($" Datum: {re.Datum:d}, Betrag: {re.Betrag}");
	}
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

class BinaryFormatterDemo {
    static readonly string name = "demo.bin";
    static void Main() {
        var kunden = new List<Kunde> {
            new Kunde(1, "Fritz", "Orth", true),
            new Kunde(2, "Ludwig", "Knüller", false)
        };

        kunden[0].Kaufen(new DateTime(2021, 03, 28), 25.0);
        kunden[0].Kaufen(new DateTime(2021, 03, 30), 120.0);
        kunden[1].Kaufen(new DateTime(2021, 03, 29), 75.0);

        Console.WriteLine("Zu sichern:");
        foreach (Kunde k in kunden)
            k.Prot();

        var desKunden = new List<Kunde>();
        using (var fs = new FileStream(name, FileMode.Create)) {
            var bifo = new BinaryFormatter();
            bifo.Serialize(fs, kunden);
            fs.Position = 0;
            Console.WriteLine("\nRekonstruiert:");
            desKunden = (List<Kunde>) bifo.Deserialize(fs);
        }
        foreach (Kunde k in desKunden)
            k.Prot();
    }
}
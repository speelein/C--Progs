using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

public class Rechnung {
	public DateTime Datum { get; set; }
	public double Betrag { get; set; }
}

public class Kunde {
    //[JsonInclude]
    public int Nr { get; private set; }
    public string Vorname { get; set; }
    public string Name { get; set; }
    public List<Rechnung> Rechnungen { get; }
    [JsonIgnore] // Eigenschaft wird nicht serialisiert.
    public bool Kredit { get; private set; }

    public Kunde(int nr, string vorname, string name, bool kredit, List<Rechnung> rechnungen) {
        Nr = nr;
        Vorname = vorname;
        Name = name;
        Kredit = kredit;
        Rechnungen = rechnungen;
    }

    [JsonConstructor] // Konstruktor wird beim Json-Deserialisieren verwendet.
    public Kunde(int nr, string vorname, string name, List<Rechnung> rechnungen) {
        Nr = nr;
        Vorname = vorname;
        Name = name;
        Rechnungen = rechnungen;
    }

    public void Kaufen(DateTime datum, double betrag) {
		Rechnungen.Add(new Rechnung { Datum = datum, Betrag = betrag });
	}

	public void Prot() {
        Console.WriteLine("\nKundennummer: \t" + Nr);
        Console.WriteLine("Name: \t\t" + Vorname + " " + Name);
		Console.WriteLine("Kredit: \t" + Kredit);
        Console.WriteLine("Rechnungen:");
		foreach (var re in Rechnungen)
			Console.WriteLine($" Datum: {re.Datum:d}, Betrag: {re.Betrag}");
	}
}

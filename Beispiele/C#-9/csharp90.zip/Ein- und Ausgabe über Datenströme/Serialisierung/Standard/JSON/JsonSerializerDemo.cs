﻿using System;
using System.Collections.Generic;
using System.Text.Json;

class JsonSerializerDemo {
    static void Main() {
        var kunden = new List<Kunde>();
        kunden.Add(new Kunde(1, "Fritz", "Orth", true, new List<Rechnung>()));
        kunden.Add(new Kunde(2, "Ludwig", "Knüller", false, new List<Rechnung>()));
        kunden[0].Kaufen(new DateTime(2021, 03, 28), 25.0);
        kunden[0].Kaufen(new DateTime(2021, 03, 30), 120.0);
        kunden[1].Kaufen(new DateTime(2021, 03, 29), 75.0);

        Console.WriteLine("Zu sichern:");
        foreach (Kunde k in kunden)
            k.Prot();

        var jsonOptions = new JsonSerializerOptions {
            WriteIndented = true,
            IncludeFields = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        string kundenJS = JsonSerializer.Serialize(kunden, jsonOptions);

        Console.WriteLine("\nJson-String:\n" + kundenJS);

        var desKunden = JsonSerializer.Deserialize<List<Kunde>>(kundenJS, jsonOptions);
        Console.WriteLine("\nRekonstruiert:");
        foreach (Kunde k in desKunden)
            k.Prot();
    }
}
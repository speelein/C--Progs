﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

class A {
	public B bref;
	public string name;
}

class B {
	public C cref;
	public string name;
}

class C {
	public A aref;
	public string name;
}

class ZirkelSerialisierungJson {
	static void Main() {
		A a = new A(); B b = new B(); C c = new C();
		a.bref = b; a.name = "a-Obj";
		b.cref = c; b.name = "b-Obj";
		c.aref = a; c.name = "c-Obj";

		var jsonOptions = new JsonSerializerOptions {
			WriteIndented = true,
			IncludeFields = true,
			ReferenceHandler = ReferenceHandler.Preserve
		};

		string aJS = JsonSerializer.Serialize(a, jsonOptions);
		Console.WriteLine(aJS);

		var desA = JsonSerializer.Deserialize<A>(aJS, jsonOptions);
		Console.WriteLine("Rekonstruiert: " + desA.bref.cref.aref.name);
		Console.WriteLine((b == desA.bref));
	}
}
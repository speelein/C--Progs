﻿using System;
using System.IO;

class Dateiverwaltung {
	static void Main() {
		const string pfad0 = @"U:\Eigene Dateien\C#\EA";
		const string pfad1 = @"U:\Eigene Dateien\C#\EA\demo.txt";
		const string pfad2 = @"U:\Eigene Dateien\C#\EA\kopie.txt";
		const string pfad3 = @"U:\Eigene Dateien\C#\EA\nn.txt";

		// Verzeichnis erstellen (setzt das LW U: voraus)
		Directory.CreateDirectory(pfad0);

		// File.CreateText(pfad1) entspricht new StreamWriter(pfad1).
		using (StreamWriter sw = File.CreateText(pfad1))
			sw.WriteLine("File-Demo");

		// Kopieren (Überschreiben erlaubt)
		File.Copy(pfad1, pfad2, true);
		Console.Write("Datei kopiert. Weiter mit Enter"); Console.ReadLine();

		File.Delete(pfad2);

		Console.WriteLine("\nExistiert " + pfad3 + "? " + File.Exists(pfad3));

		// Umbenennen (pfad1 u. pfad3 befinden sich im selben Ordner)
		File.Move(pfad1, pfad3);
		Console.WriteLine("\nDatei umbenannt. Weiter mit Enter"); Console.ReadLine();

		// Kreations- und Änderungsdatum setzen
		File.SetCreationTime(pfad3, new DateTime(2007, 12, 29, 22, 55, 44));
		File.SetLastWriteTime(pfad3, new DateTime(2005, 12, 29, 22, 55, 44));

		// Per FileInfo Dateieigenschaften ermitteln
		var fi = new FileInfo(pfad3);
		Console.WriteLine($"Die Datei {fi.Name} wurde\n  erstellt:\t\t{fi.CreationTime}" +
						  $"\n  zuletzt geändert:\t{fi.LastWriteTime}");
		Console.WriteLine("\nKreativdaten gesetzt. Weiter mit Enter"); Console.ReadLine();

		// Löschen per FileInfo-Instanzmethode
		fi.Delete();
	}
}

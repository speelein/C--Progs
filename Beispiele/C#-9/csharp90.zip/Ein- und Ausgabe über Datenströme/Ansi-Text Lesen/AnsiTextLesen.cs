﻿using System;
using System.IO;
using System.Text;

class AnsiTextLesen {
    static string name = "Ansi.txt";
    static void Main() {
        using var fs = new FileStream(name, FileMode.Open, FileAccess.Read);
        var sr = new StreamReader(fs);
        Console.WriteLine("Mit UTF-8 - Kodierung gelesen:");
        while (sr.Peek() >= 0)
            Console.WriteLine(sr.ReadLine());
        fs.Position = 0;
        var enc1252 = CodePagesEncodingProvider.Instance.GetEncoding(1252);
        sr = new StreamReader(fs, enc1252);
        Console.WriteLine("\nMit ANSI - Kodierung gelesen:");
        while (sr.Peek() >= 0)
            Console.WriteLine(sr.ReadLine());
    }
}


﻿using System;
using System.IO;

class WriteReadAllLines {
    static void Main() {
        string name = "demo.txt";
        string[] text = { "Zeile 1", "Zeile 2", "Nicht übel" };
        File.WriteAllLines(name, text);

        text = File.ReadAllLines(name);
        foreach (var zeile in text)
            Console.WriteLine(zeile);
    }
}

using System;
using System.IO;

class NestedUsingDemo {
    static void Main() {
        String name = "demo.txt";
        using (StreamWriter sw = new(name)) {
            sw.WriteLine(4711);
            sw.WriteLine(3.1415926);
            sw.WriteLine("Nicht �bel");
        }

        //using (StreamReader sr = new(new FileStream(name, FileMode.Open, FileAccess.Read)))
        //    for (int i = 0; sr.Peek() >= 0; i++)
        //        Console.WriteLine("{0}:\t{1}", i, sr.ReadLine());

        //{
        //    FileStream fs = new(name, FileMode.Open, FileAccess.Read);
        //    StreamReader sr = new(fs);
        //    try {
        //        for (int i = 0; sr.Peek() >= 0; i++)
        //            Console.WriteLine("{0}:\t{1}", i, sr.ReadLine());
        //    } finally {
        //        if (sr != null)
        //            sr.Dispose();
        //    }
        //}

        using (FileStream fs = new(name, FileMode.Open, FileAccess.Read))
        using (StreamReader sr = new(fs))
            for (int i = 0; sr.Peek() >= 0; i++)
                Console.WriteLine("{0}:\t{1}", i, sr.ReadLine());
    }
}

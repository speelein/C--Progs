﻿using System;
using System.IO;

class FileShareDemoReader {
    static void Main() {
        string name = "c:\\temp\\demo.bin";
        byte[] arr = new byte[8];
        using (FileStream fs = new(name, FileMode.Open, FileAccess.Read, FileShare.Write)) {
            fs.Read(arr, 0, 8);
            foreach (byte b in arr)
                Console.WriteLine(b);
            Console.WriteLine("Enter to terminate the reader");
            Console.Read();
        }
    }
}

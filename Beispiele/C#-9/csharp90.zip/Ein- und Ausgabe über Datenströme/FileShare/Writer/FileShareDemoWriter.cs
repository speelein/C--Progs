﻿using System;
using System.IO;

class FileShareDemoWriter {
    static void Main() {
        string name = "c:\\temp\\demo.bin";
        byte[] arr = { 0, 1, 2, 3, 4, 5, 6, 7 };
        using (FileStream fs = new(name, FileMode.Create, FileAccess.Write)) {
            fs.Write(arr, 0, arr.Length);
            fs.Flush();
            Console.WriteLine("Enter to terminate the writer");
            Console.Read();
        }
    }
}

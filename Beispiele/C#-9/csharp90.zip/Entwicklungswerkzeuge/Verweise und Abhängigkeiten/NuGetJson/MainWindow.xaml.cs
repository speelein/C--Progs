﻿using System;
using System.Windows;
using Newtonsoft.Json;

namespace NuGetJson {
    public class Person {
        public string Name;
        public string Email;
        public DateTime Datum;
    }
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            Person person = new Person();
            person.Name = "Kurt Rempremerding";
            person.Email = "kurt@rempremerding.de";
            person.Datum = new DateTime(1950, 12, 8);
            tbPerson.Text = JsonConvert.SerializeObject(person, Formatting.Indented);
        }
    }
}

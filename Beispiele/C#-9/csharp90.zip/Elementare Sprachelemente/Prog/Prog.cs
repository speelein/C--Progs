﻿using System;
class Prog {
	static void Main() {
		// Platz zum Üben elementarer Sprachelemente
	}
}

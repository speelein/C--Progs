﻿using System;
class Prog5 {
    static void Main() {
        // Platz zum Üben elementarer Sprachelemente
        // unter Voraussetzung von .NET 5
    }
}

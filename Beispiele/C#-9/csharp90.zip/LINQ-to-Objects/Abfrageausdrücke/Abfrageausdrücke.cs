﻿using System;
using System.Collections.Generic;
using System.Linq;

class Customer {
	public string CustomerId { get; set; }
	public string CompanyName { get; set; }
	public string Country { get; set; }
}

class Abfrageausdrücke {
	static void Main() {
		Customer[] customers = new Customer[7];
		customers[0] = new Customer { CustomerId = "ALFKI", CompanyName = "Alfreds Futterkiste", Country = "Germany" };
		customers[1] = new Customer { CustomerId = "ANATR", CompanyName = "Ana Trujillo Emparedados y helados", Country = "Mexico" };
		customers[2] = new Customer { CustomerId = "ANTON", CompanyName = "Antonio Moreno Taquería", Country = "Mexico" };
		customers[3] = new Customer { CustomerId = "AROUT", CompanyName = "Around the Horn", Country = "UK" };
		customers[4] = new Customer { CustomerId = "BERGS", CompanyName = "Berglunds snabbköp", Country = "Sweden" };
		customers[5] = new Customer { CustomerId = "BLAUS", CompanyName = "Blauer See Delikatessen", Country = "Germany" };
		customers[6] = new Customer { CustomerId = "BLONP", CompanyName = "Blondesddsl père et fils", Country = "France" };

		var compNames = from c in customers
							where c.Country == "Germany"
							orderby c.CompanyName.Length
							select c.CompanyName.ToUpper();

		foreach (var c in compNames)
			Console.WriteLine(c);

		// Kombination von Erweiterungsmethoden- und Abfragesyntax
		int[] ints1 = { 1, 3, 4, 8, 9, 10 };
		int[] ints2 = { 10, 14, 18 };
		var result = (from i in ints1 where i % 2 == 0 select i).Union(ints2);
		//var result = ints1.Where(i => i % 2 == 0).Union(ints2);
		foreach (var e in result) Console.Write(e + " ");
	}
}

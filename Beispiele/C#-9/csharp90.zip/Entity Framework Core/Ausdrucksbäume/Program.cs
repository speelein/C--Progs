﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ExpressionTree {
    record BlogRec(int BlogId, string Url);

    internal class Program {
        private static void Main() {
            using var context = new BloggingContext();
            // Damit das Programm ausgeführt werden kann, muss die Datenbank EFGetStarted
            // mit den Tabellen Blogs und Posts existieren.
            // Zum Erstellen per Migration taugen die folgenden PMC-Kommandos:
            // Add-Migration InitialCreate
            // Update-Database

            var xblog = context.Blogs.Find(4);
            System.Linq.Expressions.Expression<Func<Blog, bool>> expr =
                b => b.Url.Contains("xamarin");
            Func<Blog, bool> deleg = expr.Compile();
            Console.WriteLine("URL enthält xamarin: " + deleg(xblog));

            //var blogs = context.Blogs
            //    .Select(b => (b.BlogId, b.Url)); // nicht unterstützt

            var blogRec= context.Blogs
                .Select(b => new BlogRec(b.BlogId, b.Url));

            var blogs = context.Blogs
               .OrderBy(b => b.BlogId)
               .Select(b => new { b.BlogId, b.Url });
            Console.WriteLine(blogs.ToQueryString());
        }
    }
}
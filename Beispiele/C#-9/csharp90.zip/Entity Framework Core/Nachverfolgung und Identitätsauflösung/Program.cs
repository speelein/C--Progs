﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Tracking {

    internal class Program {
        private static void Main() {
            using (var db = new BloggingContext()) {
                // Damit das Programm ausgeführt werden kann, muss die Datenbank EFGetStarted
                // mit den Tabellen Blogs und Posts existieren.
                // Zum Erstellen per Migration taugen die folgenden PMC-Kommandos:
                // Add-Migration InitialCreate
                // Update-Database

                //Console.WriteLine("Alle Posts und Blogs löschen");
                //var posts = from p in db.Posts select p;
                //db.Posts.RemoveRange(posts);
                //var blogs = from b in db.Blogs select b;
                //db.Blogs.RemoveRange(blogs);
                //int deleted = db.SaveChanges();
                //Console.WriteLine("Gelöschte Zeilen: " + deleted);

                //Console.WriteLine("\nNeue Blogs einfügen");
                //Blog blog = new Blog { Url = "http://blogs.msdn.com/adonet/" };
                //blog.Posts.Add(new Post { Title = "Adonet - Post 1" }); db.Add(blog);
                //blog = new Blog { Url = "https://devblogs.microsoft.com/visualstudio/" };
                //blog.Posts.Add(new Post { Title = "Visual Studio - Post 1" }); db.Add(blog);
                //blog = new Blog { Url = "https://devblogs.microsoft.com/aspnet/" };
                //blog.Posts.Add(new Post { Title = "Aspnet - Post 1" }); db.Add(blog);
                //blog = new Blog { Url = "https://devblogs.microsoft.com/java/" };
                //blog.Posts.Add(new Post { Title = "Java - Post 1" }); db.Add(blog);
                //blog = new Blog { Url = "https://devblogs.microsoft.com/xamarin/" };
                //blog.Posts.Add(new Post { Title = "Xamarin - Post 1" }); db.Add(blog);
                //blog = new Blog { Url = "https://devblogs.microsoft.com/math-in-office/" };
                //blog.Posts.Add(new Post { Title = "Math-in-Office - Post 1" }); db.Add(blog);
                //int changed = db.SaveChanges();
                //Console.WriteLine("Ergänzte Blogs-Zeilen: " + changed);


                // Identitätsauflösung
                var xamarin = db.Posts.Single(p => p.PostId == 5);
                var xPost = db.Posts
                                .Where(p => p.Title.Contains("Xamarin"))
                                .First();
                Console.WriteLine(xamarin == xPost);

                // Entitäts-Nachverfolgung
                xPost.Content = "Xamarin.Forms wird in MAUI überführt";
                db.SaveChanges();

                // Identitätsauflösung und Nachverfolgung abschalten
                List<Blog> blogsNT = db.Blogs.AsNoTracking().ToList();
                db.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            }
        }
    }
}
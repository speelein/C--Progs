﻿using System;
using System.Linq;

namespace LazyLoading {

    internal class Program {
        private static void Main() {
            using var db = new BloggingContext();
            // Damit das Programm ausgeführt werden kann, muss die Datenbank LazyLoading
            // mit den Tabellen Blogs und Posts existieren.
            // Zum Erstellen per Migration taugen die folgenden PMC-Kommandos:
            // Add-Migration InitialCreate
            // Update-Database

            // Kollektions-Navigationseigenschaft
            var blog = db.Blogs.First();
            Console.WriteLine("Posts zum Blog: " + blog.Url);
            foreach (var p in blog.Posts)
                Console.WriteLine(p.Title);

            // Referenz-Navigationseigenschaft
            var post = db.Posts.First();
            Console.WriteLine($"\nDer Post \"{post.Title}\" gehört zum Blog {post.Blog.Url}");
        }
    }
 }
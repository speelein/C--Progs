﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace SimpleQueries {

    internal class Program {
        private static void Main() {
            using var context = new BloggingContext();
            // Damit das Programm ausgeführt werden kann, muss die Datenbank EagerLoading
            // mit den Tabellen Blogs und Posts existieren.
            // Zum Erstellen per Migration taugen die folgenden PMC-Kommandos:
            // Add-Migration InitialCreate
            // Update-Database

            // Include() - Kollektions-Navigationseigenschaft
            var xBlog = context.Blogs
                            .Include(b => b.Posts)
                            .Where(b => b.Url.Contains("xamarin"))
                            .First();
            Console.WriteLine(xBlog.Url);
            foreach (var p in xBlog.Posts)
                Console.WriteLine(p.Title);

            // Projektion
            var xFirstA = context.Blogs
                                    .Where(b => b.Url.Contains("xamarin"))
                                    .Include(b => b.Posts)
                                    .Select(b => new { b.Url, b.Posts })
                                    .First();
            foreach (var p in xFirstA.Posts)
                Console.WriteLine(p.Title);

            var xFirstAR = context.Blogs
                                        .Where(b => b.Url.Contains("xamarin"))
                                        .Select(b => new {
                                            b.Url,
                                            Posts = b.Posts.Select(p => p.Title)
                                        })
                                        .First();
            foreach (var title in xFirstAR.Posts)
                Console.WriteLine(title);

            // Include() - Referenz-Navigationseigenschaft
            var xPost = context.Posts
                            .Include(p => p.Blog)
                            .Where(p => p.Title.Contains("xamarin"))
                            .First();
            Console.WriteLine(xPost.Blog.Url);
        }
    }
}
﻿using System;

class HalloVS
{
    static void Main()
    {
        Console.WriteLine("Hallo, echt .NET hier!");
        Console.ReadLine();
    }
}

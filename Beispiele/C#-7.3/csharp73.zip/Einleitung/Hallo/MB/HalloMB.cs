﻿using System.Windows;
class HalloMB
{
    static void Main()
    {
        MessageBox.Show("Hallo Allerseits!");
    }
}

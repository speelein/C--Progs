using System;
using System.IO;

class StreamWrtRd {
    static void Main() {
        String name = "demo.txt";
        using (var sw = new StreamWriter(name)) {
            sw.WriteLine(4711);
            sw.WriteLine(3.1415926);
            sw.WriteLine("Nicht �bel");
        }
        using (var fs = new FileStream(name, FileMode.Open, FileAccess.Read))
        using (var sr = new StreamReader(fs)) {
            Console.WriteLine("Inhalt der Datei {0}:\n", ((FileStream)sr.BaseStream).Name);
            for (int i = 0; sr.Peek() >= 0; i++)
                Console.WriteLine("{0}:\t{1}", i, sr.ReadLine());
        }
	}
}

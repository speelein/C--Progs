using System;
using System.IO;
using System.Xml.Serialization;

class XMLSerialisierung {
	static string name = "demo.bin";
	static void Main() {
		var kunde = new Kunde(1, "Fritz", "Orth", 1, 13, 426.89);

        using (var fs = new FileStream(name, FileMode.Create)) {
            XmlSerializer xmlSer = new XmlSerializer(typeof(Kunde));
            xmlSer.Serialize(fs, kunde);
            fs.Position = 0;
            Console.WriteLine("\nRekonstruiert:\n");
            var desKunde = (Kunde) xmlSer.Deserialize(fs);
            desKunde.Prot();
        }
	}
}
using System;

[Serializable]
public class Kunde {
    public int nr;
    public string vorname;
    public string name;
    int nkaeufe;
    double aussen;
    public int Stimmung { get; }

    public Kunde(int nr_, string vorname_, string name_, int stimmung_,
	             int nkaeufe_, double aussen_) {
        nr = nr_;
        vorname = vorname_;
		name = name_;
        Stimmung = stimmung_;
		nkaeufe = nkaeufe_;
		aussen = aussen_;
	}

    public Kunde() { }

	public void Prot() {
        Console.WriteLine("Kundennummer: \t" + nr);
        Console.WriteLine("Name: \t\t" + vorname + " " + name);
		Console.WriteLine("Stimmung: \t" + Stimmung);
		Console.WriteLine("Anz.Einkäufe: \t" + nkaeufe);
		Console.WriteLine("Aussenstände: \t" + aussen+ "\n");
	}
}

using System;
using System.IO;

class Dateiverwaltung {
	static void Main() {
		const string PFAD1 = @"U:\Eigene Dateien\C#\EA\demo.txt";
		const string PFAD2 = @"U:\Eigene Dateien\C#\EA\kopie.txt";
		const string PFAD3 = @"U:\Eigene Dateien\C#\EA\nn.txt";

        // File.CreateText(PFAD1) entspricht new StreamWriter(PFAD1).
        using (StreamWriter sw = File.CreateText(PFAD1))
		    sw.WriteLine("File-Demo");

		// Kopieren (�berschreiben ist erlaubt)
		File.Copy(PFAD1, PFAD2, true);
		Console.Write("Datei kopiert. Weiter mit Enter"); Console.ReadLine();

		File.Delete(PFAD2);

		Console.WriteLine("\nExistiert " + PFAD3 + "? " + File.Exists(PFAD3));

		// Umbenennen (PFAD1 u. PFAD3 befinden sich im selben Ordner)
		File.Move(PFAD1, PFAD3);
		Console.WriteLine("\nDatei umbenannt. Weiter mit Enter"); Console.ReadLine();

		// Kreations- und �nderungsdatum setzen
		File.SetCreationTime(PFAD3, new DateTime(2007, 12, 29, 22, 55, 44));
		File.SetLastWriteTime(PFAD3, new DateTime(2005, 12, 29, 22, 55, 44));

		// Per FileInfo Dateieigenschaften ermitteln
		var fi = new FileInfo(PFAD3);
		Console.WriteLine($"Die Datei {fi.Name} wurde\n  erstellt:\t\t{fi.CreationTime}"+
		                  $"\n  zuletzt ge�ndert:\t{fi.LastWriteTime}");
		Console.WriteLine("\nKreativdaten gesetzt. Weiter mit Enter"); Console.ReadLine();

		// L�schen per FileInfo-Instanzmethode
		fi.Delete();
	}
}

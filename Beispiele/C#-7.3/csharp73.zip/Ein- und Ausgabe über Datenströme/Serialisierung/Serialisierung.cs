using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

class Serialisierung {
	static string name = "demo.bin";
	static void Main() {
		var kunden = new List<Kunde>();
		kunden.Add(new Kunde(1, "Fritz", "Orth", 1, 13, 426.89));
		kunden.Add(new Kunde(2, "Ludwig", "Kn�ller", 2, 17, 89.10));
		Console.WriteLine("Zu sichern:\n");
		foreach (Kunde k in kunden)
			k.Prot();

        using (var fs = new FileStream(name, FileMode.Create)) {
            var bifo = new BinaryFormatter();
            bifo.Serialize(fs, kunden);
            fs.Position = 0;
            Console.WriteLine("\nRekonstruiert:\n");
            var desKunden = (List<Kunde>)bifo.Deserialize(fs);
            foreach (Kunde k in desKunden)
                k.Prot();
        }
	}
}
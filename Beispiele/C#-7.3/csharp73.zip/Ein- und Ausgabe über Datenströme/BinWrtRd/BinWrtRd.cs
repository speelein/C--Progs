using System;
using System.IO;

class BinWrtRd {
	static void Main() {
		String name = "demo.bin";
        using (var fso = new FileStream(name, FileMode.Create))
        using (var bw = new BinaryWriter(fso)) {
            bw.Write(4711);
            bw.Write(3.1415926);
            bw.Write("Nicht �bel");
        }

        using (var fsi = new FileStream(name, FileMode.Open, FileAccess.Read))
        using (var br = new BinaryReader(fsi))
            Console.WriteLine(br.ReadInt32() + "\n" +
                                br.ReadDouble() + "\n" +
                                br.ReadString());
	}
}

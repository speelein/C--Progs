using System;
using System.IO;

class Ordnerverwaltung {
	static void Main() {
		const string DIR1 = @"U:\Eigene Dateien\C#\EA\";
		const string DIR2 = @"U:\Eigene Dateien\C#\EA\Sub\";

		Directory.CreateDirectory(DIR2);
		Directory.SetCurrentDirectory(DIR1);

        using (var sw = File.CreateText(DIR1 + "demo.txt"))
            sw.WriteLine("Directory-Demo");

		// �ber Dateien informieren (mit Filter)
		var di = new DirectoryInfo(".");
		FileInfo[] fia = di.GetFiles("*.txt");
		Console.WriteLine("txt-Dateien in {0}", di.FullName);
		Console.WriteLine("  {0, -20} {1, -20}", "Name", "Letzte �nderung");
		foreach (FileInfo fi in fia)
			Console.WriteLine("  {0, -20} {1, -20}", fi.Name, fi.LastWriteTime);

		// �ber Unterordner informieren
		DirectoryInfo[] dia = di.GetDirectories();
		Console.WriteLine("\n\nOrdner in {0}", di.FullName);
		Console.WriteLine("  {0, -20} {1, -20}", "Name", "Letzte �nderung");
		foreach (DirectoryInfo die in dia)
			Console.WriteLine("  {0, -20} {1, -20}", die.Name, die.LastWriteTime);

		Directory.SetCurrentDirectory(DIR1+ "\\..");
		Console.WriteLine("\nDer Ordner " + DIR1 + " wird nach Enter gel�scht.");
        Console.ReadLine();
		// Ordner l�schen
		Directory.Delete(DIR1, true);
	}
}

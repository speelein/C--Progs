﻿using System;
using System.Windows;
using System.Windows.Controls;

class AttachedProperties : Window {
	AttachedProperties() {
		Title = "Angefügte Eigenschaften";
        Height = 160; Width = 320;
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.RowDefinitions.Add(new RowDefinition());
		grid.RowDefinitions.Add(new RowDefinition());
		grid.ShowGridLines = true;
		Content = grid;

		Button butt = new Button();
		butt.Content = "Knopf";
		butt.HorizontalAlignment = HorizontalAlignment.Center;
		butt.VerticalAlignment = VerticalAlignment.Center;

		Grid.SetRow(butt, 1);
		Grid.SetColumn(butt, 1);

		//butt.SetValue(Grid.RowProperty, 1);
		//butt.SetValue(Grid.ColumnProperty, 1);

		grid.Children.Add(butt);
	}

	[STAThread]
	static void Main() {
		Application app = new Application();
		AttachedProperties hf = new AttachedProperties();
		app.Run(hf);
	}
}

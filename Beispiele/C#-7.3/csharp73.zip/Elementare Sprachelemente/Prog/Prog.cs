﻿using System;
using System.Collections.Generic;


class Prog {
    static void Main() {

        String[] ass = null;
        int res = 0;
        bool sl1ok = ass?[1]?.Length == ++res;
        Console.WriteLine(res);

    }
}

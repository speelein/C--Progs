using System;

namespace MathExt {
	public static class Mathe {
		public static double H(this double arg, double expo) {
			return Math.Pow(arg, expo);
		}
	}
}


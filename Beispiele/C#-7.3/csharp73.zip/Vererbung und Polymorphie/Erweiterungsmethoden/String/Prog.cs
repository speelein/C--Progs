﻿using System;
using StringExt;
using System.Linq;

class Prog {
	static void Main() {
		Console.WriteLine("".Empty());
		Console.WriteLine("m".Empty());
	}
}


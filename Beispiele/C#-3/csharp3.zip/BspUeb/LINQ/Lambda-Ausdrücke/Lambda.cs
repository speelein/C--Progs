﻿using System;

delegate int Rest(int a, int b);
delegate bool Krit (int a);

class AnoMeth {
	static void Main() {
		// Realisation als anonyme Methode
		//Rest r = delegate(int a, int b) {
		//    return Math.Max(a, b) % Math.Min(a, b);
		//};

		//Rest r = (int a, int b) => Math.Max(a, b) % Math.Min(a, b);
		Rest R = (a, b) => Math.Max(a, b) % Math.Min(a, b);

		Krit K = a => a % 2 == 0;
		//Krit K = a => {
		//    double r = Math.Sqrt(a);
		//    return r % 1 == 0 ? true: false;
		//};
		Console.WriteLine(R(7, 25));
		Console.WriteLine(K(8));
		Console.ReadLine();
	}
}

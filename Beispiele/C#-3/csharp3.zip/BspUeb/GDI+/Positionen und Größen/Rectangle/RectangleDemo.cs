using System;
using System.Windows.Forms;
using System.Drawing;

class RectangleDemo : Form {
	Rectangle ra = new Rectangle(0, 0, 100, 100);
	Pen rotstift = new Pen(Color.Red, 5);

	RectangleDemo() {
		Text = "Rectangle - Demo";
		ClientSize = new Size(400, 400);
		FormBorderStyle = FormBorderStyle.FixedSingle;
	}

	protected override void OnPaint(PaintEventArgs e) {
		e.Graphics.DrawEllipse(rotstift, ra);
	}

	protected override void OnMouseDown(MouseEventArgs e) {
		if (e.Button == MouseButtons.Left) {
			if (e.X > Width / 2) {
				if (ra.Right < Width - 20) ra.Offset(20, 20);
			} else {
				if (ra.X >= 20) ra.Offset(-20, -20);
			}
		} else {
			if (e.X > Width / 2) {
				if (ra.X >= 20 && ra.Right < Width - 20) ra.Inflate(20, 20);
			} else {
				if (ra.Width > 20) ra.Inflate(-20, -20);
			}
		}
		Refresh();
	}

	[STAThread]
	static void Main() {
		Application.Run(new RectangleDemo());
	}
}
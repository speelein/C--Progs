﻿using System;
using System.Windows.Forms;
using System.Drawing;

class PointAndSize : Form {
	Pen pen = new Pen(Color.Black, 3);

	PointAndSize() {
		Text = "Point and Size";
		ResizeRedraw = true;
		ClientSize = new Size(200, 200);
	}

	protected override void OnPaint(PaintEventArgs e) {
		Graphics g = e.Graphics;
		Point pkt1 = new Point(); // Initialisierung mit (0, 0)!
		Point pkt2 = pkt1 + ClientSize;
		g.DrawLine(pen, pkt1, pkt2);
		int distX = (ClientSize.Width - 10) / 5;
		int distY = (ClientSize.Height - 10) / 5;
		pkt1.Offset(distX/2, distY/2);
		for (int i = 0; i < 5; i++) {
			g.DrawEllipse(pen, pkt1.X, pkt1.Y, 10, 10);
			pkt1.Offset(distX, distY);
		}
	}

	[STAThread]
	static void Main() {
		Application.Run(new PointAndSize());
	}
}
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

class Splines : Form {
	Pen stift = new Pen(Color.Black, 10);

	protected override void OnPaint(PaintEventArgs e) {
		Graphics g = e.Graphics;

		// DrawCurve()
		//Text = "DrawCurve";
		//Point[] pts = {new Point(50, 70),
		//          new Point(100, 100),
		//          new Point(100, 200),
		//          new Point(250, 50),
		//          new Point(300, 100)};
		//g.DrawCurve(stift, pts);


		// DrawClosedCurve()
		//Text = "DrawClosedCurve";
		//Point[] pts = {new Point(50, 70),
		//          new Point(100, 100),
		//          new Point(100, 200),
		//          new Point(250, 50),
		//          new Point(300, 100)};
		//g.DrawClosedCurve(stift, pts);

		//g.FillEllipse(Brushes.Red, 45, 65, 10, 10);
		//g.FillEllipse(Brushes.Red, 95, 95, 10, 10);
		//g.FillEllipse(Brushes.Red, 95, 195, 10, 10);
		//g.FillEllipse(Brushes.Red, 245, 45, 10, 10);
		//g.FillEllipse(Brushes.Red, 295, 95, 10, 10);

		// DrawBezier()
		Text = "DrawBezier";
		Point p0 = new Point(150, 250);
		Point p1 = new Point(100, 50);
		Point p2 = new Point(300, 50);
		Point p3 = new Point(250, 250);
		g.DrawBezier(stift, p0, p1, p2, p3);
		g.FillEllipse(Brushes.Red, 145, 245, 10, 10);
		g.DrawString("P0", Font, Brushes.Black, 125, 245);
		g.FillEllipse(Brushes.Red, 95, 45, 10, 10);
		g.DrawString("P1", Font, Brushes.Black, 75, 45);
		g.FillEllipse(Brushes.Red, 295, 45, 10, 10);
		g.DrawString("P2", Font, Brushes.Black, 308, 45);
		g.FillEllipse(Brushes.Red, 245, 245, 10, 10);
		g.DrawString("P3", Font, Brushes.Black, 258, 245);
		g.DrawLine(Pens.Red, p1, p0);
		g.DrawLine(Pens.Red, p2, p3);

		// DrawBeziers()
		//Text = "DrawBeziers";
		//Point q1 = new Point(205, 400);
		//Point q2 = new Point(400, 400);
		//Point q3 = new Point(350, 250);
		//Point[] pts = {p0, p1, p2, p3, q1, q2, q3};
		//g.DrawBeziers(stift, pts);
		//g.DrawString(", Q0", Font, Brushes.Black, 272, 245);
		//g.FillEllipse(Brushes.Red, 245, 245, 10, 10);
		//g.DrawString("Q1", Font, Brushes.Black, 213, 395);
		//g.FillEllipse(Brushes.Red, 200, 395, 10, 10);
		//g.DrawLine(Pens.Red, p3, q1);
		//g.FillEllipse(Brushes.Red, 395, 395, 10, 10);
		//g.DrawString("Q2", Font, Brushes.Black, 410, 395);
		//g.FillEllipse(Brushes.Red, 345, 245, 10, 10);
		//g.DrawString("Q3", Font, Brushes.Black, 360, 245);
		//g.DrawLine(Pens.Red, q2, q3);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Splines());
	}
}

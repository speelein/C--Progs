using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;

class Koch : Form {
	List<PointF> punkte = new List<PointF>();
	PointF[] pts;

	Koch() {
		Text = "Kochsche Schneeflocke";
		Width = 550; Height = 560;
		BackColor = Color.AntiqueWhite;
		PointF start = new PointF(0.0f, 0.0f);
		punkte.Add(start);
		SizeF kante = new SizeF(100.0f, 0.0f);
		rotate(ref kante);
		punkte.Add(start + kante);
		punkte.Add(new PointF(100.0f, 0.0f));
		for (int i = 0; i < 4; i++) {
			addPoints(punkte);
		}
		pts = punkte.ToArray();
	}

	void rotate(ref SizeF vektor) {
		double winkel = 1.0 / 3.0 * Math.PI;
		float cos60 = (float)Math.Cos(winkel);
		float sin60 = (float)Math.Sin(winkel);
		float oldX = vektor.Width;
		vektor.Width = cos60 * vektor.Width - sin60 * vektor.Height;
		vektor.Height = sin60 * oldX + cos60 * vektor.Height;
	}

	void addPoints(List<PointF> punkte) {
		PointF a, e;
		int nr = 0;
		while (nr <= punkte.Count - 1) {
			a = punkte[nr];
			if (nr < punkte.Count - 1)
				e = punkte[nr + 1];
			else
				e = punkte[0];
			SizeF kante = new SizeF(e.X - a.X, e.Y - a.Y);
			float faktor = (float)(1.0 / 3.0);
			kante.Width *= faktor;
			kante.Height *= faktor;
			PointF n1 = a + kante;
			PointF n2 = n1 + kante;
			punkte.Insert(nr + 1, n1);
			rotate(ref kante);
			punkte.Insert(nr + 2, n1 + kante);
			punkte.Insert(nr + 3, n2);
			nr = nr + 4;
		}
	}

	protected override void OnPaint(PaintEventArgs e) {
		Graphics g = e.Graphics;
		g.PageUnit = GraphicsUnit.Millimeter;
		g.TranslateTransform(20, 40);
		g.FillPolygon(Brushes.FloralWhite, pts);
		g.DrawPolygon(Pens.Blue, pts);

		//SizeF kante = new SizeF(100.0f, 0.0f);
		//rotate(ref kante, 1);
		//PointF p1 = new Point(0, 0);
		//p1 = p1 + kante;
		//PointF[] test = {new PointF(0, 0), p1, new PointF(100, 0)};
		//g.DrawPolygon(Pens.Red, test);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Koch());
	}
}
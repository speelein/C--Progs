// Beispiel nach Petzold 2002, S. 178

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

class Stern : Form {
	Point[] pts = new Point[5];

	Stern() {
		Text = "Stern";
		ClientSize = new Size(350, 350);
		
		// Stern-Eckpunkte berechnen
		int shift = 180, len = 150;
		double winkel = 3 * Math.PI / 2;
		for (int i = 0; i < pts.Length; i++) {
			double kosinus = Math.Cos(winkel);
			double sinus = Math.Sin(winkel);
			int x = (int) (shift + kosinus * len);
			int y = (int) (shift + sinus * len);
			pts[i] = new Point(x, y);
			winkel += 4 * Math.PI / 5;
		}
	}

	protected override void OnPaint(PaintEventArgs e) {
		for (int i = 0; i < pts.Length; i++) {
			e.Graphics.DrawString(i.ToString(), Font, SystemBrushes.WindowText, pts[i].X - 5, pts[i].Y - 5);
		}
		e.Graphics.FillPolygon(Brushes.MediumSeaGreen, pts, FillMode.Alternate);
		//e.Graphics.FillPolygon(Brushes.MediumSeaGreen, pts, FillMode.Winding);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Stern());
	}
}

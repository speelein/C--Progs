using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

class Linien : Form {
	Pen stift = new Pen(Color.Black, 10);
	Point[] pts = {new Point(10, 10),
		        new Point(10, 100),
		        new Point(100, 100),
		        new Point(110, 50)};

	protected override void OnPaint(PaintEventArgs e) {
		Graphics g = e.Graphics;

		// DrawLines()
		Text = "DrawLines";
		stift.LineJoin = LineJoin.Round;
		g.DrawLines(stift, pts);

		// 1-Pixel - Problem
		//Text = "1-Pixel - Problem";
		//stift.Width = 3;
		//g.DrawRectangle(stift, 5, 5, 5, 5);
		//g.DrawRectangle(Pens.Red, 5, 5, 5, 5);

		// Antialiasing
		//g.SmoothingMode = SmoothingMode.HighQuality;
		//g.DrawEllipse(stift, 15, 15, 50, 50);

		// DrawArc()
		//Text = "DrawArc";
		//stift.EndCap = LineCap.ArrowAnchor;
		//g.DrawArc(stift, 10, 10, 200, 200, 0, 270);

		// DrawPie()
		//Text = "DrawPie";
		//stift.LineJoin = LineJoin.Round;
		//g.DrawPie(stift, 10, 10, 200, 200, 0, 270);

		// DrawPolygon()
		//Text = "DrawPolygon";
		//g.DrawPolygon(stift, pts);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Linien());
	}
}

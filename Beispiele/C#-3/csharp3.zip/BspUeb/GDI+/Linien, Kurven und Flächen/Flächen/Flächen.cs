using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

class Flaechen : Form {
	protected override void OnPaint(PaintEventArgs e) {
		Graphics g = e.Graphics;

		// FillRectangle()
		//Text = "FillRectangle";
		//g.FillRectangle(Brushes.Red, 5, 5, 1, 1);

		// FillEllipse()
		//Text = "FillEllipse";
		//g.FillEllipse(Brushes.Blue, 10, 10, 100, 150);

		// FillPie()
		Text = "FillPie";
		Pen pen = new Pen(Color.Black, 5);
		g.FillPie(Brushes.Aquamarine, 10, 10, 200, 200, 0, 270);
		g.DrawPie(pen, 10, 10, 200, 200, 0, 270);

		// FillPolygon()
		//Text = "FillPolygon";
		//Point[] pts = {new Point(10, 10),
		//        new Point(10, 100),
		//        new Point(100, 100),
		//        new Point(110, 50)};
		//g.FillPolygon(Brushes.MediumSeaGreen, pts);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Flaechen());
	}
}

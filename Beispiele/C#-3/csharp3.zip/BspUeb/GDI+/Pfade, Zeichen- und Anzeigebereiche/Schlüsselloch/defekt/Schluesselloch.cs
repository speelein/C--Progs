using System.Windows.Forms;
using System.Drawing;
using System;

class Schluesselloch : Form {
	Pen stift = new Pen(Color.Black, 10);
	Point ul, ur, p0, p1, p2, p3;
	Point[] lz;

	Schluesselloch() {
		Text = "Schl�sselloch";
		ClientSize = new Size(500, 400);
		ul = new Point(150, 350);
		ur = new Point(350, 350);
		p0 = new Point(200, 200);
		p1 = new Point(70, 10);
		p2 = new Point(430, 10);
		p3 = new Point(300, 200);
		lz = new Point[] { p0, ul, ur, p3 };
	}

	protected override void OnPaint(PaintEventArgs e) {
		e.Graphics.DrawLines(stift, lz);
		e.Graphics.DrawBezier(stift, p0, p1, p2, p3);
	}

	[STAThread]
	static void Main() {
		Application.Run(new Schluesselloch());
	}
}

class HalloEE {
	static void Main() {
        System.Windows.Forms.MessageBox.Show("Hallo Allerseits!");
    }
}

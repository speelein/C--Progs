using System;
class Hallo {
	static void Main() {
		Console.WriteLine("Hallo Allerseits!");
	}
}
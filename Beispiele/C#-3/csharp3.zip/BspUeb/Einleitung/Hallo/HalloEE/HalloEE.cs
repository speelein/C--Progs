﻿using System;
class HalloEE {
    static void Main() {
        Console.WriteLine("Hallo Allerseits!");
        Console.ReadLine();
    }
}
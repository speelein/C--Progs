// Primzahlen ermitteln per Ochsentour
// GUI-Version
using System;
using Microsoft.VisualBasic;
using System.Windows.Forms;

class PrimitivGUI {
	static void Main() {
		bool tg;
		ulong i, mtk, zahl;
		string ergebnis;
		while (true) {
            string input = Interaction.InputBox("Zu untersuchende positive Zahl:",
                             "Einfacher Primzahlendetektor", "", 500, 300);
            // Wenn der Benutzer die InpuBox abbricht (cancel oder Kreuz in Titelzeile)
			// liefert InputBox() eine leere Zeichenfolge.
			if (input == "")
				break;

            if (!UInt64.TryParse(input, out zahl)) {
                MessageBox.Show("Keine Zahl (im zul�ssigen Bereich)!", "Einfacher Primzahlendetektor", MessageBoxButtons.OK,
                                MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1);
                continue;
            }

            if (zahl == 0)
				break;

			tg = false;
			mtk = (ulong) Math.Sqrt(zahl);	//Maximaler Teilerkandidat
			for (i = 2; i <= mtk; i++)
				if (zahl % i == 0) {
					tg = true;
					break;
				}
			if (tg)
				ergebnis = zahl + " ist keine Primzahl.\n(Teiler: " + i + ")";
			else
				ergebnis = zahl + " ist eine Primzahl.";
			MessageBox.Show(ergebnis, "Einfacher Primzahlendetektor", MessageBoxButtons.OK,
			                MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
		}
		MessageBox.Show("Vielen Dank f�r den Einsatz dieser Software!",
		                "Einfacher Primzahlendetektor", MessageBoxButtons.OK);
	}
}

// dllmain.h : Deklaration der Modulklasse.

class CComSvrAtlModule : public CAtlDllModuleT< CComSvrAtlModule >
{
public :
	DECLARE_LIBID(LIBID_ComSvrAtlLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_COMSVRATL, "{9D91B1E6-8566-482D-9F94-31557D713FFD}")
};

extern class CComSvrAtlModule _AtlModule;

// DmEuroConv.cpp: Implementierung von CDmEuroConv

#include "stdafx.h"
#include "DmEuroConv.h"


// CDmEuroConv


STDMETHODIMP CDmEuroConv::ToEuro(DOUBLE dm, DOUBLE* euro)
{
	// TODO: F�gen Sie hier Ihren Implementierungscode ein.
	*euro = dm / 1.95583;
	return S_OK;
}

STDMETHODIMP CDmEuroConv::ToDm(DOUBLE euro, DOUBLE* dm)
{
	// TODO: F�gen Sie hier Ihren Implementierungscode ein.
	*dm = euro * 1.95583;
	return S_OK;
}

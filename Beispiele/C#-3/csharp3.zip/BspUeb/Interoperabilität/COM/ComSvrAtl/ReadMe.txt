﻿========================================================================
    AKTIVE VORLAGENBIBLIOTHEK: ComSvrAtl-Projektübersicht
========================================================================

Der Anwendungs-Assistent hat dieses ComSvrAtl-Projekt als
Ausgangspunkt zum Schreiben der DLL erstellt.

Die Datei enthält eine Zusammenfassung des Inhalts der Dateien für
das Projekt.

ComSvrAtl.vcproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem Anwendungs-
    Assistenten generiert werden.
    Sie enthält Informationen zu der Version von Visual C++, mit der die Datei 
    generiert wurde, sowie Informationen zu Plattformen, Konfigurationen und 
    Projektfeatures, die mit dem dem Anwendungs-Assistenten generiert werden.

ComSvrAtl.idl
    Diese Datei enthält die IDL-Definitionen der Typbibliothek, die 
    Schnittstellen und Co-Klassen, die im Projekt definiert sind.
    Diese Datei wird vom MIDL-Compiler verarbeitet, um Folgendes zu generieren:
        C++-Schnittstellendefinitionen und
        GUID-Deklarationen          (ComSvrAtl.h)
        GUID-Definitionen           (ComSvrAtl_i.c)
        Eine Typbibliothek          (ComSvrAtl.tlb)
        Marshallingcode             (ComSvrAtl_p.c und dlldata.c)

ComSvrAtl.h
    Diese Datei enthält die C++-Schnittstellendefinitionen und 
    GUID-Deklarationen der in ComSvrAtl.idl definierte Elemente. 
    Sie wird von MIDL während der Kompilierung erneut generiert.

ComSvrAtl.cpp
    Diese Datei enthält die Objekttabelle und die Implementierung der 
    DLL-Exporte.

ComSvrAtl.rc
    Hierbei handelt es sich um eine Auflistung aller Ressourcen von Microsoft 
    Windows, die vom Programm verwendet werden.

ComSvrAtl.def
    Die Moduldefinitionsdatei enthält die Linkerinformationen zu den Exporten, 
    die für die DLL erforderlich sind. Sie enthält Exporte für:
DllGetClassObject
DllCanUnloadNow
DllRegisterServer
DllUnregisterServer

/////////////////////////////////////////////////////////////////////////////
Andere Standarddateien:

StdAfx.h, StdAfx.cpp
    Mit diesen Dateien werden eine vorkompilierte Headerdatei (PCH)
    mit dem Namen ComSvrAtl.pch sowie eine vorkompilierte 
    Typendatei mit dem Namen StdAfx.obj erstellt.

Resource.h
    Dies ist die Standardheaderdatei, die Ressourcen-IDs definiert.

/////////////////////////////////////////////////////////////////////////////
Proxy/Stub-DLL-Projekt und Moduldefinitionsdatei:

ComSvrAtlps.vcproj
    Dies ist die Projektdatei zum Erstellen einer Proxy/Stub-DLL.
	Die IDL-Datei im Hauptprojekt muss mindestens eine Schnittstelle 
        enthalten. Die IDL-Datei muss vor dem Erstellen der Proxy/Stub-DLL 
        kompiliert werden. In diesem Prozess werden die erforderlichen Dateien 
        dlldata.c, ComSvrAtl_i.c und ComSvrAtl_p.c 
        generiert, die Proxy/Stub-DLL zu generieren.

ComSvrAtlps.def
    Die Moduldefinitionsdatei enthält die Linkerinformationen zu den Exporten,
    die für den Proxy/Stub erforderlich sind.

/////////////////////////////////////////////////////////////////////////////

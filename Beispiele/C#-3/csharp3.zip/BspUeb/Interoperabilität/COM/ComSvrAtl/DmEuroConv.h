// DmEuroConv.h: Deklaration von CDmEuroConv

#pragma once
#include "resource.h"       // Hauptsymbole

#include "ComSvrAtl_i.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Singlethread-COM-Objekte werden auf der Windows CE-Plattform nicht vollst�ndig unterst�tzt. Windows Mobile-Plattformen bieten beispielsweise keine vollst�ndige DCOM-Unterst�tzung. Definieren Sie _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA, um ATL zu zwingen, die Erstellung von Singlethread-COM-Objekten zu unterst�tzen und die Verwendung eigener Singlethread-COM-Objektimplementierungen zu erlauben. Das Threadmodell in der RGS-Datei wurde auf 'Free' festgelegt, da dies das einzige Threadmodell ist, das auf Windows CE-Plattformen ohne DCOM unterst�tzt wird."
#endif



// CDmEuroConv

class ATL_NO_VTABLE CDmEuroConv :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDmEuroConv, &CLSID_DmEuroConv>,
	public IDispatchImpl<IDmEuroConv, &IID_IDmEuroConv, &LIBID_ComSvrAtlLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CDmEuroConv()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DMEUROCONV)

DECLARE_NOT_AGGREGATABLE(CDmEuroConv)

BEGIN_COM_MAP(CDmEuroConv)
	COM_INTERFACE_ENTRY(IDmEuroConv)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:

	STDMETHOD(ToEuro)(DOUBLE dm, DOUBLE* euro);
	STDMETHOD(ToDm)(DOUBLE euro, DOUBLE* dm);
};

OBJECT_ENTRY_AUTO(__uuidof(DmEuroConv), CDmEuroConv)

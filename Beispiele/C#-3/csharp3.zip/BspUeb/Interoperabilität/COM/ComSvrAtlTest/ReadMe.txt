﻿========================================================================
    KONSOLENANWENDUNG: ComSvrAtlTest-Projektübersicht
========================================================================

Diese ComSvrAtlTest-Anwendung wurde vom Anwendungs-Assistenten 
für Sie erstellt.

Die Datei enthält eine Zusammenfassung des Inhalts der Dateien,
aus denen die ComSvrAtlTest-Anwendung besteht.


ComSvrAtlTest.vcproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem Anwendungs-
    Assistenten generiert werden.
    Sie enthält Informationen zu der Version von Visual C++, mit der die Datei 
    generiert wurde, sowie Informationen zu Plattformen, Konfigurationen und 
    Projektfeatures, die mit dem dem Anwendungs-Assistenten generiert werden.

ComSvrAtlTest.cpp
    Dies ist die Hauptquelldatei der Anwendung.

/////////////////////////////////////////////////////////////////////////////
Andere Standarddateien:

StdAfx.h, StdAfx.cpp
    Mit diesen Dateien werden eine vorkompilierte Headerdatei (PCH)
    mit dem Namen ComSvrAtlTest.pch sowie eine vorkompilierte 
    Typendatei mit dem Namen StdAfx.obj erstellt.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "TODO:"-Kommentare, um die Teile des 
Quellcodes anzugeben, die hinzugefügt oder bearbeitet werden müssen.

/////////////////////////////////////////////////////////////////////////////

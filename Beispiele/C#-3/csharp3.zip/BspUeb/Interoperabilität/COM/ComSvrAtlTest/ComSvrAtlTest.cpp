// ComSvrAtlTest.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include <iostream>
#include "../ComSvrAtl/ComSvrAtl_i.h"
#include "../ComSvrAtl/ComSvrAtl_i.c"
using namespace std;

int main() {	
	HRESULT returnCode;
	IDmEuroConv* pDEC;
	returnCode = CoInitialize(0);
	if (SUCCEEDED(returnCode)) {
		returnCode = CoCreateInstance(		
			CLSID_DmEuroConv,
			NULL,
			CLSCTX_INPROC_SERVER,
			IID_IDmEuroConv,
			(void**) &pDEC);
		if (SUCCEEDED(returnCode)) {
			double dm, euro;
			cout << "Euro <-> DM - Konvertierung\n\nEuro-Betrag:\t";
			cin >> euro;
			cin.get();
			pDEC->ToDm(euro, &dm);
			pDEC->Release();
			cout << "DM-Betrag:\t" << dm << endl;
		} else 
			cout << "COM-Server konnte nicht instantiiert werden." << endl;
	} else
		cout << "COM konnte nicht initialisiert werden." << endl;
	cin.get();
	CoUninitialize();
	return 0;
}


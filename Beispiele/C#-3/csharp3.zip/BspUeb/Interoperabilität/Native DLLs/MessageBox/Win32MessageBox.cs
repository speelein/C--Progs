using System;
class Win32MessageBox {
	[System.Runtime.InteropServices.DllImport("user32.dll")]
	static extern int MessageBox(int hWnd, string text, string titel, int typ);

	static void Main() {
		MessageBox(0, "MessageBox - Funktion aus user32.dll", "Win32-API", 0);
	}
}

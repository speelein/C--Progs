using System;
class Prog {
	static void Main() {
		Figur fig = new Figur(50.0, 50.0);
		Kreis krs = new Kreis(10.0, 10.0, 5.0);
		Console.ReadLine();
	}
}

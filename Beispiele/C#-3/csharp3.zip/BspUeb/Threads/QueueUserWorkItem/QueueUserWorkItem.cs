using System;
using System.Threading;

class Prog {
	static Random zzg = new Random();

	static void HintergrundAktion(object anz) {
		long summe;
		for (int i = 0; i < (int)anz; i++) {
			summe = 0;
			for (int j = 0; j < 10000000; j++)
				summe += zzg.Next(100);
			Console.WriteLine("Aktuelle Zufallssumme: " + summe);
		}
		Console.WriteLine("\nDer Arbeits-Thread ist fertig");
	}

	static void Main() {
		bool b = ThreadPool.QueueUserWorkItem(HintergrundAktion, 5);
		Console.WriteLine("Arbeitsauftrag erfolgreich in die "+
			"Threadpool-Warteschlange gestellt: {0}\n",b);
		Console.WriteLine("Der prim�re Thread schl�ft 5 Sekunden lang\n");
		Thread.Sleep(5000);
		Console.WriteLine("\nDer prim�re Thread ist aufgewacht.\n");
		Console.ReadLine();
	}
}
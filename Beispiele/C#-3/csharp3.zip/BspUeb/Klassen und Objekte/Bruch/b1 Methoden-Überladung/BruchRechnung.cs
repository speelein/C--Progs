using System;
class BruchRechnung {
    static void Main() {
        Bruch b = new Bruch();
        Console.WriteLine("K�rze Deinen Bruch:\n");
        b.Frage();
        b.Kuerze();
        b.Etikett = "Der gek�rzte Bruch:";
        b.Zeige();
        Console.ReadLine();
    }
}
using System;

class Fakul {
	static String instr;
	
	static int Kon2Int() {
		int arg = -1;
		try {
			arg = Convert.ToInt32(instr);
			if (arg < 0  || arg > 170)
				throw new BadFakulArgException("Wert ausselhalb [0, 170]", instr, 3, arg);
			else
				return arg;
		}
		catch (FormatException e) {
			String str = instr;
			bool ok = false;
			while (str.Length > 1 && !ok) {
				str = str.Substring(0, str.Length - 1);
				ok = Int32.TryParse(str, out arg);
			}
			if (ok) {
				instr = str;
				return arg;
			} else
				throw new BadFakulArgException("Fehler beim Konvertieren", instr, 1, -1, e);
		} catch (OverflowException e) {
			throw new BadFakulArgException("Integer-�berlauf", instr, 2, -1, e);
		}
	}

	static void Main(string[] args) {
		int argument = -1;
		if (args.Length == 0) {
			Console.WriteLine("Kein Argument angegeben");
			Console.Read();
			Environment.Exit(1);
		} else
			instr = args[0];

		try {
			argument = Kon2Int();
		}
		catch (BadFakulArgException e) {
			Console.WriteLine("Message:\t" + e.Message);
			Console.WriteLine("Fehlertyp:\t{0}\nZeichenfolge:\t{1} ", e.Type, e.Input);
			Console.WriteLine("Wert:    \t" + e.Value);
			if (e.InnerException != null)
				Console.WriteLine("Orig. Message:\t" + e.InnerException.Message);
			Console.Read();
			Environment.Exit(1);
		}
		double fakul = 1.0;
		for (int i = 1; i <= argument; i++)
			fakul = fakul * i;
		Console.WriteLine("Fakult�t von {0}: {1}", instr, fakul);
		Console.Read();
	}
}

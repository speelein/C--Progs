using System;
using System.Windows.Forms;
using System.Drawing;

class Kollision : Form {
	public Kollision() {
		Text = "Kollision in .NET 2";
		Size = new Size(260, 100);
		ResizeRedraw = true;
		// .NET 1 - L�sung
		//this.Menu = new MainMenu();
		//MenuItem mitFile, mitEdit, mitTools, mitHelp;
		//mitFile = Menu.MenuItems.Add("&Datei");
		//mitEdit = Menu.MenuItems.Add("&Bearbeiten");
		//mitTools = Menu.MenuItems.Add("&Extras");
		//mitHelp = Menu.MenuItems.Add("&Hilfe");
		// .NET 2 - L�sung
		MenuStrip mainMenu = new MenuStrip();
		Controls.Add(mainMenu);
		ToolStripMenuItem mitFile, mitEdit, mitTools, mitHelp;
		mitFile = new ToolStripMenuItem("&Datei");
		mitEdit = new ToolStripMenuItem("&Bearbeiten");
		mitTools = new ToolStripMenuItem("&Extras");
		mitHelp = new ToolStripMenuItem("&Hilfe");
		mainMenu.Items.AddRange(new ToolStripItem[] { mitFile, mitEdit, mitTools, mitHelp });
	}
	protected override void OnPaint(PaintEventArgs e) {
		Pen stift = new Pen(Color.Black, 2);
		e.Graphics.DrawLine(stift, 0, 0, ClientSize.Width, ClientSize.Height);
	}
	[STAThread]
	static void Main() {
		Application.EnableVisualStyles();
		Application.Run(new Kollision());
	}
}
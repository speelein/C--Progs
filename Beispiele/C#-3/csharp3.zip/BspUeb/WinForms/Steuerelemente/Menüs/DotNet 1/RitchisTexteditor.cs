// Ritchis Texteditor mit Men� in .NET 1.x - Technik

using System;
using System.Windows.Forms;
using System.Drawing;

class RitchisTexteditor : Form {
	RichTextBox editor;
	MenuItem mitFile, mitEdit, mitTools, mitHelp,
			 mitUndo, mitRedo, mitCut, mitCopy, mitPaste, mitDel, mitSelectAll,
			 cmitUndo, cmitRedo, cmitCut, cmitCopy, cmitPaste, cmitDel, cmitSelectAll,
			 mitFont, mitCourierNew, mitTimesNewRoman, mitArial, mitCurrentFont,
			 mitSize,
			 mitInfo;
	Font fontTNR12, fontCN12, fontA12, fontTNR16, fontCN16, fontA16;

	public RitchisTexteditor() {
		fontTNR12 = new Font("Times New Roman", 12);
		fontCN12 = new Font("Courier New", 12);
		fontA12 = new Font("Arial", 12);
		fontTNR16 = new Font("Times New Roman", 16);
		fontCN16 = new Font("Courier New", 16);
		fontA16 = new Font("Arial", 16);

		Text = "Ritchis Texteditor";
		editor = new RichTextBox();
		editor.Font = fontTNR12;
		editor.Dock = DockStyle.Fill;
		editor.HideSelection = false;
		editor.AcceptsTab = true;
		Controls.Add(editor);

		this.Menu = new MainMenu();
		mitFile = Menu.MenuItems.Add("&Datei");
		mitEdit = Menu.MenuItems.Add("&Bearbeiten");
		mitEdit.Popup += new EventHandler(MitEditOnPopup);
		mitTools = Menu.MenuItems.Add("&Extras");
		mitHelp = Menu.MenuItems.Add("&Hilfe");

		mitFile.MenuItems.Add(new MenuItem("&Beenden", new EventHandler(MitExitOnClick)));

		// Untermen� Bearbeiten
		mitUndo = mitEdit.MenuItems.Add("&R�ckg�ngig", new EventHandler(MitUnRedoOnClick));
		mitUndo.Shortcut = Shortcut.CtrlZ;
		mitRedo = mitEdit.MenuItems.Add("&Wiederholen", new EventHandler(MitUnRedoOnClick));
		mitRedo.Shortcut = Shortcut.CtrlY;
		mitEdit.MenuItems.Add("-");
		mitCut = mitEdit.MenuItems.Add("&Ausschneiden", new EventHandler(MitCutOnClick));
		mitCut.Shortcut = Shortcut.CtrlX;
		mitCopy = mitEdit.MenuItems.Add("&Kopieren",	new EventHandler(MitCopyOnClick));
		mitCopy.Shortcut = Shortcut.CtrlC;
		mitPaste = mitEdit.MenuItems.Add("&Einf�gen", new EventHandler(MitPasteOnClick));
		mitPaste.Shortcut = Shortcut.CtrlV;
		mitDel = mitEdit.MenuItems.Add("&L�schen", new EventHandler(MitDeleteOnClick));
		mitDel.Shortcut = Shortcut.Del;
		mitEdit.MenuItems.Add("-");
		mitSelectAll = mitEdit.MenuItems.Add("Alles &markieren", new EventHandler(MitSelectAllOnClick));
		mitSelectAll.Shortcut = Shortcut.CtrlA;

		mitFont = mitTools.MenuItems.Add("&Schriftart");
		EventHandler fontHandler = new EventHandler(MitFontOnClick);
		mitCourierNew = new MenuItem("&Courier New", fontHandler);
		mitCourierNew.RadioCheck = true;
		mitFont.MenuItems.Add(mitCourierNew);
		mitTimesNewRoman = new MenuItem("&Times New Roman", fontHandler);
		mitTimesNewRoman.Checked = true;
		mitTimesNewRoman.RadioCheck = true;
		mitCurrentFont = mitTimesNewRoman;
		mitFont.MenuItems.Add(mitTimesNewRoman);
		mitArial = new MenuItem("&Arial", fontHandler);
		mitArial.RadioCheck = true;
		mitFont.MenuItems.Add(mitArial);

		mitSize = new MenuItem("&Gro�e Schrift", new EventHandler(MitSizeOnClick));
		mitSize.Checked = false;
		mitTools.MenuItems.Add(mitSize);
		
		mitInfo = new MenuItem("&Info",
													 new EventHandler(MitInfoOnClick),
													 Shortcut.F1);
		mitHelp.MenuItems.Add(mitInfo);

		// Kontextmen�  mit Bearbeiten-Items
		cmitUndo = new MenuItem("&R�ckg�ngig",new EventHandler(MitUnRedoOnClick));
		cmitRedo = new MenuItem("&Wiederholen", new EventHandler(MitUnRedoOnClick));
		cmitCut = new MenuItem("&Ausschneiden", new EventHandler(MitCutOnClick));
		cmitCopy = new MenuItem("&Kopieren",	new EventHandler(MitCopyOnClick));
		cmitPaste =	new MenuItem("&Einf�gen",	new EventHandler(MitPasteOnClick));
		cmitDel = new MenuItem("&L�schen", new EventHandler(MitDeleteOnClick));
		cmitSelectAll = new MenuItem("Alles &markieren", new EventHandler(MitSelectAllOnClick));
		MenuItem[] cmi = {cmitUndo, cmitRedo, new MenuItem("-"),
			 cmitCut, cmitCopy, cmitPaste, new MenuItem("-"), cmitSelectAll};
		editor.ContextMenu = new ContextMenu(cmi);
		editor.ContextMenu.Popup += EditorContextMenuOnPopup;

	} //Ende Konstruktor RitchisTexteditor

	protected void MitExitOnClick(object sender, EventArgs e) {
		Close();
	}

	protected void MitFontOnClick(object sender, EventArgs e) {
		mitCurrentFont.Checked = false;
		mitCurrentFont = (MenuItem)sender;
		mitCurrentFont.Checked = true;

		if (sender == mitCourierNew) {
			editor.Font = (mitSize.Checked ? fontCN16 : fontCN12);
		} else
			if (sender == mitTimesNewRoman) {
				editor.Font = (mitSize.Checked ? fontTNR16 : fontTNR12);
			} else {
				editor.Font = (mitSize.Checked ? fontA16 : fontA12);
			}
	}

	protected void MitSizeOnClick(object sender, EventArgs e) {
		mitSize.Checked ^= true;
		if (mitCurrentFont == mitCourierNew) {
			editor.Font = (mitSize.Checked ? fontCN16 : fontCN12);
		} else
			if (mitCurrentFont == mitTimesNewRoman) {
				editor.Font = (mitSize.Checked ? fontTNR16 : fontTNR12);
			} else {
				editor.Font = (mitSize.Checked ? fontA16 : fontA12);
			}
	}

		// Click-Handler zum Bearbeiten
	protected void MitUnRedoOnClick(object sender, EventArgs e) {
		if (sender == mitUndo || sender == cmitUndo)
			editor.Undo();
		else
			editor.Redo();
	}
protected void MitCutOnClick(object sender, EventArgs e) {
	editor.Cut();
}
	protected void MitCopyOnClick(object sender, EventArgs e) {
		editor.Copy();
	}
	protected void MitPasteOnClick(object sender, EventArgs e) {
		editor.Paste();
	}
	protected void MitDeleteOnClick(object sender, EventArgs e) {
		if (editor.SelectionLength == 0 && editor.SelectionStart < editor.TextLength)
			editor.Select(editor.SelectionStart, 1);
		editor.SelectedText = "";
	}
	protected void MitSelectAllOnClick(object sender, EventArgs e) {
		editor.SelectAll();
	}
	protected void MitEditOnPopup(object sender, EventArgs e) {
		if (editor.CanUndo) {
			mitUndo.Enabled = true;
		} else {
			mitUndo.Enabled = false;
		}
		if (editor.CanRedo) {
			mitRedo.Enabled = true;
		} else {
			mitRedo.Enabled = false;
		}
		if (editor.SelectionLength > 0) {
			mitCut.Enabled = true;
			mitCopy.Enabled = true;
			mitDel.Enabled = true;
		} else {
			mitCut.Enabled = false;
			mitCopy.Enabled = false;
			mitDel.Enabled = false;
		}
		if (Clipboard.ContainsText()) {
			mitPaste.Enabled = true;
		} else {
			mitPaste.Enabled = false;
		}
		if (editor.TextLength > 0) {
			mitSelectAll.Enabled = true;
		} else {
			mitSelectAll.Enabled = false;
		}
	}

	protected void EditorContextMenuOnPopup(object sender, EventArgs e) {
		if (editor.CanUndo) {
			cmitUndo.Enabled = true;
		} else {
			cmitUndo.Enabled = false;
		}
		if (editor.CanRedo) {
			cmitRedo.Enabled = true;
		} else {
			cmitRedo.Enabled = false;
		}
		if (editor.SelectionLength > 0) {
			cmitCut.Enabled = true;
			cmitCopy.Enabled = true;
			cmitDel.Enabled = true;
		} else {
			cmitCut.Enabled = false;
			cmitCopy.Enabled = false;
			cmitDel.Enabled = false;
		}
		if (Clipboard.ContainsText()) {
			cmitPaste.Enabled = true;
		} else {
			cmitPaste.Enabled = false;
		}
		if (editor.TextLength > 0) {
			cmitSelectAll.Enabled = true;
		} else {
			cmitSelectAll.Enabled = false;
		}
	}

	protected void MitInfoOnClick(object sender, EventArgs e) {
		MessageBox.Show(Text + "  \u00A9 by Mirko Weich");
	}

	[STAThread]
	static void Main() {
		Application.EnableVisualStyles();
		Application.Run(new RitchisTexteditor());
	}
}
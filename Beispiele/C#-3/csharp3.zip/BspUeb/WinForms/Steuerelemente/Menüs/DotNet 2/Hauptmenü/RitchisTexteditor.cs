using System;
using System.Windows.Forms;
using System.Drawing;

class RitchisTexteditor : Form {
	RichTextBox editor;
	ToolStripMenuItem	mitFile, mitEdit, mitTools, mitHelp,
						mitQuit,
						mitCut, mitCopy, mitPaste, mitDel,
						mitFont, mitCourierNew, mitTimesNewRoman, mitArial, mitCurrentFont,
						mitSize,
						mitBackColor, mitBeige, mitWhite, mitCurrentColor,
						mitInfo;
	Font fontTNR12, fontCN12, fontA12, fontTNR16, fontCN16, fontA16;

	public RitchisTexteditor() {
		fontTNR12 = new Font("Times New Roman", 12);
		fontCN12 = new Font("Courier New", 12);
		fontA12 = new Font("Arial", 12);
		fontTNR16 = new Font("Times New Roman", 16);
		fontCN16 = new Font("Courier New", 16);
		fontA16 = new Font("Arial", 16);

		Text = "Ritchis Texteditor";
		editor = new RichTextBox();
		editor.Font = fontTNR12;
		editor.HideSelection = false;
		editor.AcceptsTab = true;
		editor.Dock = DockStyle.Fill;
		Controls.Add(editor);

		MenuStrip mainMenu = new MenuStrip();
		mainMenu.Dock = DockStyle.Top;
		Controls.Add(mainMenu);
		// erlaubt dem Benutzer, per Alt+Maus die Reihenfolge der Mn�itemns zu �ndern:
		//mainMenu.AllowItemReorder = true;
		// Zeilenumbruch f�r Men�items bei horizontaler Platznot:
		mainMenu.LayoutStyle = ToolStripLayoutStyle.Flow;
		
		mitFile = new ToolStripMenuItem("&Datei");
		mitEdit = new ToolStripMenuItem("&Bearbeiten");
		mitTools = new ToolStripMenuItem("&Extras");
		mitHelp = new ToolStripMenuItem("&Hilfe");
		mainMenu.Items.AddRange(new ToolStripItem[]
			{mitFile, mitEdit, mitTools, mitHelp});

		// Men�items Datei
		mitQuit = new ToolStripMenuItem("&Beenden", null, new EventHandler(MitExitOnClick));
		mitFile.DropDownItems.Add(mitQuit);

		// Men�items Bearbeiten
		Bitmap bmp = new Bitmap("cut.bmp");
		bmp.MakeTransparent(bmp.GetPixel(0, 0));
		mitCut = new ToolStripMenuItem("&Ausschneiden", bmp, MitCutOnClick);
		mitCut.ShortcutKeys = Keys.Control | Keys.X;

		bmp = new Bitmap("copy.bmp");
		bmp.MakeTransparent(bmp.GetPixel(0, 0));
		mitCopy = new ToolStripMenuItem("&Kopieren", bmp, MitCopyOnClick);
		mitCopy.ShortcutKeys = Keys.Control | Keys.C;
	
		bmp = new Bitmap("paste.bmp");
		bmp.MakeTransparent(bmp.GetPixel(0, 0));
		mitPaste = new ToolStripMenuItem("&Einf�gen", bmp, MitPasteOnClick);
		mitPaste.ShortcutKeys = Keys.Control | Keys.V;

		bmp = new Bitmap("del.bmp");
		bmp.MakeTransparent(bmp.GetPixel(0, 0));
		mitDel = new ToolStripMenuItem("&L�schen", bmp, MitDeleteOnClick);
		mitDel.ShortcutKeys = Keys.Delete;

		mitEdit.DropDownItems.AddRange(new ToolStripItem[] { mitCut, mitCopy, mitPaste, mitDel});
		mitEdit.DropDownOpening += MitEditOnDropDownOpening;

		// Men�items Extras
		mitFont = new ToolStripMenuItem("&Schriftart");

		EventHandler fontHandler = new EventHandler(MitFontOnClick);
		mitCourierNew = new ToolStripMenuItem("&Courier New", null, fontHandler);
		mitFont.DropDownItems.Add(mitCourierNew);

		mitTimesNewRoman = new ToolStripMenuItem("&Times New Roman", null, fontHandler);
		mitTimesNewRoman.Checked = true;
		mitCurrentFont = mitTimesNewRoman;
		mitFont.DropDownItems.Add(mitTimesNewRoman);

		mitArial = new ToolStripMenuItem("&Arial", null, fontHandler);
		mitFont.DropDownItems.Add(mitArial);

		mitTools.DropDownItems.Add(mitFont);

		mitSize = new ToolStripMenuItem("&Gro�e Schrift", null, new EventHandler(MitSizeOnClick));

		mitTools.DropDownItems.Add(mitSize);
		mitTools.DropDownItems.Add(new ToolStripSeparator());

		mitBackColor = new ToolStripMenuItem("&Hintergrundfarbe");
		mitTools.DropDownItems.Add(mitBackColor);

		EventHandler bcHandler = new EventHandler(MitBackColorOnClick);
		mitWhite = new ToolStripMenuItem("&Weiss", null, bcHandler);
		mitCurrentColor = mitWhite;
		mitWhite.Checked = true;
		mitBackColor.DropDownItems.Add(mitWhite);
		mitBeige = new ToolStripMenuItem("&Beige", null, bcHandler);
		mitBackColor.DropDownItems.Add(mitBeige);

		// Men�items Hilfe
		mitInfo = new ToolStripMenuItem("&Info", null, new EventHandler(MitInfoOnClick));
		mitInfo.ShortcutKeys = Keys.F1;
		mitHelp.DropDownItems.Add(mitInfo);
		//mitInfo.Visible = false;

	} // Ende Formularkonstruktor

	protected void MitExitOnClick(object sender, EventArgs e) {
		Close();
	}

	// Click-Handler zum Hauptmen�-Item Bearbeiten
	protected void MitCutOnClick(object sender, EventArgs e) {
		editor.Cut();
	}
	protected void MitCopyOnClick(object sender, EventArgs e) {
		editor.Copy();
	}
	protected void MitDeleteOnClick(object sender, EventArgs e) {
		if (editor.SelectionLength == 0 && editor.SelectionStart < editor.TextLength)
			editor.Select(editor.SelectionStart, 1);
		editor.SelectedText = "";
	}
	protected void MitPasteOnClick(object sender, EventArgs e) {
		MessageBox.Show("Paste");
		if (Clipboard.ContainsText())
			editor.Paste();
	}

	protected void MitEditOnDropDownOpening(object sender, EventArgs e) {
		if (editor.SelectionLength > 0) {
			mitCut.Enabled = true;
			mitCopy.Enabled = true;
			mitDel.Enabled = true;
		} else {
			mitCut.Enabled = false;
			mitCopy.Enabled = false;
			mitDel.Enabled = false;
		}
		if (Clipboard.ContainsText()) {
			mitPaste.Enabled = true;
		} else {
			mitPaste.Enabled = false;
		}
	}

	protected void MitFontOnClick(object sender, EventArgs e) {
		mitCurrentFont.Checked = false;
		mitCurrentFont = (ToolStripMenuItem) sender;
		mitCurrentFont.Checked = true;

		if (sender == mitCourierNew) {
			editor.Font = (mitSize.Checked ? fontCN16 : fontCN12);
		} else
			if (sender == mitTimesNewRoman) {
				editor.Font = (mitSize.Checked ? fontTNR16 : fontTNR12);
			} else {
				editor.Font = (mitSize.Checked ? fontA16 : fontA12);
			}
	}

	protected void MitSizeOnClick(object sender, EventArgs e) {
		mitSize.Checked ^= true;
		if (mitCurrentFont == mitCourierNew) {
			editor.Font = (mitSize.Checked ? fontCN16 : fontCN12);
		} else
			if (mitCurrentFont == mitTimesNewRoman) {
				editor.Font = (mitSize.Checked ? fontTNR16 : fontTNR12);
			} else {
				editor.Font = (mitSize.Checked ? fontA16 : fontA12);
			}
	}

	protected void MitBackColorOnClick(object sender, EventArgs e) {
		mitCurrentColor.Checked = false;
		mitCurrentColor = (ToolStripMenuItem)sender;
		mitCurrentColor.Checked = true;

		if (sender == mitBeige)
			editor.BackColor = Color.Beige;
		else
			editor.BackColor = Color.White;
	}

	protected void MitInfoOnClick(object sender, EventArgs e) {
		MessageBox.Show(Text + "  \u00A9 by Mirko Weich");
	}

	[STAThread]
	static void Main() {
		Application.EnableVisualStyles();
		Application.Run(new RitchisTexteditor());
	}
}